"""
Apport package hook for kloudos-driver (requires Apport 2.5 or newer).

Copyright (C) 2005-2013 System76, Inc.
Copyright (C) 2020- KloudOS.
"""

from apport.hookutils import attach_file_if_exists

LOGS = (
    ('DriverLog', '/var/log/kloudos-driver.log'),
    ('DaemonLog', '/var/log/upstart/kloudos-driver.log'),
)

def add_info(report):
    report['CrashDB'] = "{'impl': 'launchpad', 'project': 'kloudos-driver'}"
    for (key, filename) in LOGS:
        attach_file_if_exists(report, filename, key)

