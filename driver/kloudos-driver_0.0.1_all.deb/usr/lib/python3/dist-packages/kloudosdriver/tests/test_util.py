# kloudos-driver: Universal driver for kloudos computers
# Copyright (C) 2005-2016 System76, Inc.
# Copyright (C) 2020- KloudOS.
#
# This file is part of `kloudos-driver`.
#
# `kloudos-driver` is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# `kloudos-driver` is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with `kloudos-driver`; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""
Unit tests for `kloudosdriver.util` module.
"""

from unittest import TestCase
import os
from os import path
import shutil

from .helpers import TempDir
from kloudosdriver.mockable import SubProcess
from kloudosdriver import util


class TestFunctions(TestCase):
    def test_create_tmp_logs(self):
        SubProcess.reset(mocking=False)
        (tmp, tgz) = util.create_tmp_logs(func=None)
        self.assertTrue(path.isdir(tmp))
        self.assertTrue(tmp.startswith('/tmp/logs.'))
        self.assertEqual(
            sorted(os.listdir(tmp)),
            ['kloudos-logs', 'kloudos-logs.tgz'],
        )
        self.assertEqual(tgz, path.join(tmp, 'kloudos-logs.tgz'))
        self.assertTrue(path.isfile(tgz))
        self.assertTrue(path.isdir(path.join(tmp, 'kloudos-logs')))
        shutil.rmtree(tmp)

    def test_create_logs(self):
        SubProcess.reset(mocking=False)
        tmp = TempDir()
        tgz = util.create_logs(tmp.dir, func=None)
        self.assertEqual(tgz, tmp.join('kloudos-logs.tgz'))
        self.assertTrue(path.isfile(tgz))

